﻿namespace BorderControl
{
    public interface IIdentifiable
    {

        public string Name { get; set; }

    }
}
