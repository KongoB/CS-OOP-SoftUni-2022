﻿namespace BorderControl
{
    public abstract class Entities
    {

        public string Id { get; set; }


    }
}
