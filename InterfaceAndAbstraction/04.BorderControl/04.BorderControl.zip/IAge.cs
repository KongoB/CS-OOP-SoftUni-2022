﻿namespace BorderControl
{
    public interface IAge
    {
        public int Age { get; set; }

    }
}
